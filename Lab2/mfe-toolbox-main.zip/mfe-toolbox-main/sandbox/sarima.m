function sarima(y,c,p,q,d,seasonal,x,startingVals,options,holdBack,sigma2)



